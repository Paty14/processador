ipPROCESS LaTeX documents template
=============

LaTeX template for documents based in the ipPROCESS targered to IP-core development.

Documentation Note
------------------
A full documentation is under development. If you have any contribution, please place a pull request.

Known Dependencies
------------
Template users are reporting some issues due to faults in compilaton process. Most of theses problems may be conected to LaTeX miss dependencies. Here is a list of packages used by this template.

* xcolor
* color
* paralist
* graphicx
* url
* array
* ragged2e
* sectsty
* float
* placeins
* subcaption
* epstopdf
* fancyhdr
* enumitem
